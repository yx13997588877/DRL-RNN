# coding: utf-8
# user: YYX
# date: 2021/4/11
from __future__ import absolute_import

from pyrl import gru
from pyrl import linear
from pyrl import simple

Networks = {
    'linear': linear.Linear,
    'gru':    gru.GRU,
    'simple': simple.Simple
    }